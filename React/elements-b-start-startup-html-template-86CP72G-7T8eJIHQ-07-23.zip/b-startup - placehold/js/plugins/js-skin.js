    (function($){
    $(document).ready(function() {
    
        
    });
    })(jQuery);
     /*2020-06-22 14:57*//* JS Generator Execution Time: 0.00010490417480469 seconds */