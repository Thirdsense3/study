export default function Logo(){

    return(
        <a href="/" className="d-flex align-items-center col-md-2 mb-2 mb-md-0 px-4 text-decoration-none">
                TheUNIONGraphix
        </a>
    );
}