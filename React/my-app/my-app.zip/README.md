npm install 
npm start
